# Animated Star Rating

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/jOegJxR](https://codepen.io/Codewithshobhit/pen/jOegJxR).

A star rating where stars pop out one by one if you choose a higher rating.