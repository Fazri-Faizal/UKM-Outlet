<head>
    <link rel="stylesheet" href="/css/title-logo.css" />
</head>

<main class="text-container">
    <svg class="text-stroke" viewBox="0 10 650 100" width="100%" height="100%">
        <text class="text" x="30" y="100">UKM OUTLET</text>
    </svg>
</main>
<button class="reset">Restart the Animation</button>

<script type="text/javascript" src="/js/title-logo.js"></script>